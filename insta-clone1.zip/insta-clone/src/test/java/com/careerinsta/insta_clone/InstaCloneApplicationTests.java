package com.careerinsta.insta_clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstaCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
