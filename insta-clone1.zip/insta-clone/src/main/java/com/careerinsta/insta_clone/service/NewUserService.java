import com.careerinsta.insta_clone.entity.User;
import com.careerinsta.insta_clone.repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class NewUserService {

    private final UserRepository userRepository;

    @Autowired
    public NewUserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Other methods...

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    public void updateUser(User user) {
        userRepository.save(user); // Assuming you have a UserRepository extending JpaRepository
    }
    public void deleteUser(Long id) {
        userRepository.deleteById(id); // Assuming userRepository extends JpaRepository
    }

}
