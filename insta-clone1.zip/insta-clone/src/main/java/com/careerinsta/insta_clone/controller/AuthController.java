package com.careerinsta.insta_clone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.careerinsta.insta_clone.entity.User;
import com.careerinsta.insta_clone.service.NewUserService;
import java.util.List;

@RestController
public class AuthController {

    private final NewUserService userService;

    @Autowired
    public AuthController(NewUserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        if (userService.findByUserName(user.getUserName()) != null) {
            return ResponseEntity.badRequest().body("Username already taken.");
        }

        userService.registerUser(user);
        return ResponseEntity.ok("User registered successfully.");
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User loginUser) {
        User user = userService.findByUserName(loginUser.getUserName());

        if (user != null && userService.passwordMatches(loginUser.getPasswordHash(), user.getPasswordHash())) {
            return ResponseEntity.ok("Login successful.");
        } else {
            return ResponseEntity.status(401).body("Invalid credentials.");
        }
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        if (users.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(users);
    }

    @PutMapping("/users/{id}")
    public ResponseEntity<String> updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
        User existingUser = userService.findById(id);

        if (existingUser == null) {
            return ResponseEntity.notFound().build();
        }

        // Update user fields based on the provided data
        if (updatedUser.getUserName() != null) {
            if (!existingUser.getUserName().equals(updatedUser.getUserName()) &&
                userService.findByUserName(updatedUser.getUserName()) != null) {
                return ResponseEntity.badRequest().body("Username already taken.");
            }
            existingUser.setUserName(updatedUser.getUserName());
        }

        if (updatedUser.getEmail() != null) {
            existingUser.setEmail(updatedUser.getEmail());
        }

        if (updatedUser.getPasswordHash() != null) {
            existingUser.setPasswordHash(updatedUser.getPasswordHash());
        }

        userService.updateUser(existingUser);
        return ResponseEntity.ok("User updated successfully.");
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        User user = userService.findById(id);

        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully.");
    }
}
